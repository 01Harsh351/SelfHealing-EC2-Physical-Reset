
import time
import boto3
import serial

from botocore.config import Config
from botocore.exceptions import ClientError, BotoCoreError

REGION = "us-east-1"
GROUP_NAME = "Self_Healing"
SERIAL_PORT = "rfc2217://127.0.0.1:4000"

# Keep False until the complete workflow is verified.
REAL_AWS_RESET = False

POLL_INTERVAL = 4
RECOVERY_TIMEOUT = 600

aws_config = Config(
    connect_timeout=3,
    read_timeout=5,
    retries={
        "max_attempts": 3,
        "mode": "standard"
    }
)

asg = boto3.client(
    "autoscaling",
    region_name=REGION,
    config=aws_config
)


def get_group():
    response = asg.describe_auto_scaling_groups(
        AutoScalingGroupNames=[GROUP_NAME]
    )

    groups = response.get("AutoScalingGroups", [])

    if not groups:
        raise RuntimeError(
            f"Auto Scaling Group not found: {GROUP_NAME}"
        )

    return groups[0]


def healthy_instances(group):
    return [
        instance
        for instance in group.get("Instances", [])
        if instance.get("LifecycleState") == "InService"
        and instance.get("HealthStatus") == "Healthy"
    ]


def send(arduino, command):
    arduino.write((command + "\n").encode("utf-8"))
    arduino.flush()
    print("LED command:", command, flush=True)


def reset_ec2(arduino):
    group = get_group()

    if group["DesiredCapacity"] != 1:
        raise RuntimeError(
            "Expected DesiredCapacity=1; reset cancelled"
        )

    healthy = healthy_instances(group)

    if len(healthy) != 1:
        raise RuntimeError(
            f"Expected one healthy EC2; found {len(healthy)}"
        )

    old_id = healthy[0]["InstanceId"]
    print("Current EC2:", old_id, flush=True)

    send(arduino, "RECOVERING")

    if not REAL_AWS_RESET:
        print("SAFE TEST: No EC2 termination requested.")
        time.sleep(2)
        send(arduino, "HEALTHY")
        print("Simulation complete.")
        return

    print("Requesting EC2 replacement...", flush=True)

    asg.terminate_instance_in_auto_scaling_group(
        InstanceId=old_id,
        ShouldDecrementDesiredCapacity=False
    )

    deadline = time.monotonic() + RECOVERY_TIMEOUT

    while time.monotonic() < deadline:
        time.sleep(POLL_INTERVAL)

        group = get_group()

        replacements = [
            instance
            for instance in healthy_instances(group)
            if instance["InstanceId"] != old_id
        ]

        if replacements:
            new_id = replacements[0]["InstanceId"]

            print(
                f"Replacement healthy: {new_id}",
                flush=True
            )
            send(arduino, "HEALTHY")
            print("RECOVERY SUCCESSFUL", flush=True)
            return

        print(
            "Waiting for replacement EC2...",
            flush=True
        )

    raise TimeoutError(
        "Replacement did not become healthy within 600 seconds"
    )


def main():
    print("Connecting to Wokwi...", flush=True)

    with serial.serial_for_url(
        SERIAL_PORT,
        baudrate=115200,
        timeout=1
    ) as arduino:

        print("WOKWI CONNECTED!", flush=True)

        try:
            group = get_group()

            send(
                arduino,
                "HEALTHY"
                if healthy_instances(group)
                else "ERROR"
            )

            print("AWS CONNECTION SUCCESSFUL", flush=True)

        except (ClientError, BotoCoreError, RuntimeError) as error:
            print("Initial AWS check failed:", error, flush=True)
            send(arduino, "ERROR")

        while True:
            message = arduino.readline().decode(
                "utf-8",
                errors="replace"
            ).strip()

            if message == "RESET":
                print("\nRESET BUTTON PRESSED!", flush=True)

                try:
                    reset_ec2(arduino)

                except (
                    ClientError,
                    BotoCoreError,
                    RuntimeError,
                    TimeoutError,
                    OSError,
                ) as error:
                    print("RECOVERY FAILED:", error, flush=True)
                    send(arduino, "ERROR")

            elif message:
                print("Arduino:", message, flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Bridge stopped.", flush=True)
    except (serial.SerialException, OSError) as error:
        print("CONNECTION ERROR:", error, flush=True)

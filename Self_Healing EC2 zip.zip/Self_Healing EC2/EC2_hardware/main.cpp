
#include <Arduino.h>

const int BUTTON = 2;
const int GREEN = 8;
const int YELLOW = 9;
const int RED = 10;

bool previousButton = HIGH;
bool recoveryActive = false;
unsigned long lastChange = 0;

void setLED(bool g, bool y, bool r) {
  digitalWrite(GREEN, g);
  digitalWrite(YELLOW, y);
  digitalWrite(RED, r);
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);
  pinMode(BUTTON, INPUT_PULLUP);
  pinMode(GREEN, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(RED, OUTPUT);

  setLED(false, false, true);
  Serial.println("SYSTEM READY");
}

void loop() {
  bool current = digitalRead(BUTTON);

  if (current != previousButton) {
    lastChange = millis();
  }

  static bool stableButton = HIGH;

  if (millis() - lastChange >= 50 &&
      current != stableButton) {
    stableButton = current;

    if (stableButton == LOW && !recoveryActive) {
      recoveryActive = true;
      setLED(false, true, false);
      Serial.println("RESET");
    }
  }

  previousButton = current;

  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    command.trim();

    if (command == "HEALTHY") {
      setLED(true, false, false);
      recoveryActive = false;
      Serial.println("RECOVERY SUCCESSFUL");
    }
    else if (command == "RECOVERING") {
      setLED(false, true, false);
      recoveryActive = true;
      Serial.println("RECOVERY IN PROGRESS");
    }
    else if (command == "ERROR") {
      setLED(false, false, true);
      recoveryActive = false;
      Serial.println("RECOVERY FAILED");
    }
  }

  delay(10);
}


#include <Arduino.h>

#define BUTTON 2
#define GREEN 8
#define YELLOW 9
#define RED 10

bool previousButton = HIGH;
bool recoveryActive = false;
unsigned long lastPressTime = 0;

void setLED(bool green, bool yellow, bool red) {
  digitalWrite(GREEN, green ? HIGH : LOW);
  digitalWrite(YELLOW, yellow ? HIGH : LOW);
  digitalWrite(RED, red ? HIGH : LOW);
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);

  pinMode(BUTTON, INPUT_PULLUP);
  pinMode(GREEN, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(RED, OUTPUT);

  // Initial state: waiting for AWS connection
  setLED(false, false, true);

  Serial.println("SYSTEM READY");
  Serial.println("Waiting for AWS status...");
}

void loop() {
  bool currentButton = digitalRead(BUTTON);

  // Trigger only once per button press
  if (previousButton == HIGH &&
      currentButton == LOW &&
      millis() - lastPressTime > 300 &&
      !recoveryActive) {

    lastPressTime = millis();
    recoveryActive = true;

    setLED(false, true, false);

    Serial.println("RESET");
    Serial.println("RECOVERY IN PROGRESS");
  }

  previousButton = currentButton;

  // Receive recovery result from Python
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    command.trim();

    if (command == "HEALTHY") {
      setLED(true, false, false);
      recoveryActive = false;
      Serial.println("RECOVERY SUCCESSFUL");
    }

    else if (command == "RECOVERING") {
      setLED(false, true, false);
      recoveryActive = true;
    }

    else if (command == "ERROR") {
      setLED(false, false, true);
      recoveryActive = false;
      Serial.println("RECOVERY FAILED");
    }
  }

  delay(20);
}


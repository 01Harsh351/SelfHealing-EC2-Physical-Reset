
import time
import boto3
import streamlit as st
from botocore.exceptions import ClientError, BotoCoreError

REGION = "us-east-1"
GROUP = "Self_Healing"

st.set_page_config(page_title="Self-Healing EC2", page_icon="☁️")
st.title("☁️ Self-Healing EC2 Physical Reset")
st.caption("AWS Academy Learner Lab | Live Recovery Dashboard")

asg = boto3.client("autoscaling", region_name=REGION)

# Save recovery details across dashboard refreshes
if "old_instance" not in st.session_state:
    st.session_state.old_instance = None

if "recovering" not in st.session_state:
    st.session_state.recovering = False

try:
    response = asg.describe_auto_scaling_groups(
        AutoScalingGroupNames=[GROUP]
    )
    groups = response["AutoScalingGroups"]

    if not groups:
        st.error("Auto Scaling Group not found.")
        st.stop()

    group = groups[0]
    instances = group["Instances"]

    healthy = [
        i for i in instances
        if i["LifecycleState"] == "InService"
        and i["HealthStatus"] == "Healthy"
    ]

    st.success("✅ AWS Connected")
    st.metric("Desired Capacity", group["DesiredCapacity"])

    st.subheader("EC2 Instance Status")

    for instance in instances:
        st.write(
            instance["InstanceId"],
            "—",
            instance["LifecycleState"],
            "—",
            instance["HealthStatus"]
        )

    old_id = st.session_state.old_instance

    if st.session_state.recovering:
        replacement = [
            i for i in healthy
            if i["InstanceId"] != old_id
        ]

        if replacement:
            st.session_state.recovering = False
            st.success("🟢 GREEN LED — Replacement EC2 Healthy!")
            st.write("Old Instance:", old_id)
            st.write("New Instance:", replacement[0]["InstanceId"])
        else:
            st.warning("🟡 YELLOW LED — Recovery in progress")

    elif healthy:
        st.success("🟢 GREEN LED — EC2 Healthy")

    else:
        st.error("🔴 RED LED — No healthy instance detected")

    st.divider()
    st.subheader("Physical Reset Simulation")

    st.warning(
        "Reset will terminate the selected EC2 instance. "
        "AWS Auto Scaling should launch a replacement."
    )

    confirm = st.checkbox("I understand this will terminate an EC2 instance")

    if st.button(
        "🔴 RESET EC2",
        disabled=not confirm or not healthy or st.session_state.recovering
    ):
        instance_id = healthy[0]["InstanceId"]

        result = asg.terminate_instance_in_auto_scaling_group(
            InstanceId=instance_id,
            ShouldDecrementDesiredCapacity=False
        )

        st.session_state.old_instance = instance_id
        st.session_state.recovering = True

        st.warning(f"🟡 Recovery started for {instance_id}")
        st.rerun()

except (ClientError, BotoCoreError) as error:
    st.error(f"AWS API Error: {error}")

except Exception as error:
    st.error(f"Error: {error}")

st.divider()

if st.button("🔄 Refresh Status"):
    st.rerun()

if st.session_state.recovering:
    st.caption("Refresh every 10–20 seconds to check recovery.")
